<?php
session_start();
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin' && $_SESSION['user_role'] !== 'faculty') {
    session_unset(); //Remove session variables, destroy the session and bring user back to login page if unauthorised
    session_destroy();
    header("Location: login.php");
    exit();
    die("Access denied. Only admins or faculty are allowed.");
}
if (!isset($_GET['csrf_token']) || $_GET['csrf_token'] !== $_SESSION['csrf_token']) {
    die("CSRF token validation failed!");
    exit();
}
if (isset($_GET['metric_number']) && isset($_GET['action'])) {
    // Store the metric_number in the session
    $_SESSION['metric_number'] = $_GET['metric_number'];

    // Action check and go to corresponding page
    if ($_GET['action'] === 'edit') {
        // Redirect to edit page
        header("Location: index.php?route=edit");
        exit;
    } elseif ($_GET['action'] === 'assign') {
        // Redirect to assign page
        header("Location: index.php?route=assign");
        exit;
    } elseif ($_GET['action'] === 'delete') {
        // Redirect to delete page
        header("Location: index.php?route=delete");
        exit;
    } else {
        // If action is invalid, redirect back to the main page
        header("Location: index.php");
        exit;
    }
} else {
    // If the necessary parameters are not set, redirect to the main page
    header("Location: index.php");
    exit;
}
?>