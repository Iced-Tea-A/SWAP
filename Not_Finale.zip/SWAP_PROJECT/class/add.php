<?php
// add.php
include 'db_connection.php';
session_start();

if (!isset($_SESSION['role_id']) || ($_SESSION['role_id'] != 1 && $_SESSION['role_id'] != 2)) {
    header("Location: login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    die("Invalid request method.");
}

// Case 1: Adding a new class name only.
if (isset($_POST['classname']) && !isset($_POST['classtype']) && !isset($_POST['courseCode'])) {
    $classname = trim($_POST['classname']);
    // Check if the class already exists.
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM classname WHERE name = ?");
    $stmt->execute([$classname]);
    if ($stmt->fetchColumn() > 0) {
        die("Class name already exists.");
    }
    $stmt = $pdo->prepare("INSERT INTO classname (name) VALUES (?)");
    if ($stmt->execute([$classname])) {
        header("Location: modify.php?message=Class name added successfully");
        exit;
    } else {
        die("Failed to add class name.");
    }
}

// Case 2: Adding a full class (requires classname, classtype, and courseCode).
if (!isset($_POST['classname'], $_POST['classtype'], $_POST['courseCode'])) {
    die("Missing parameters.");
}

$classname = trim($_POST['classname']);
$classtype = trim($_POST['classtype']);
$courseCode = trim($_POST['courseCode']);

// Get the new class IDs.
$stmt = $pdo->prepare("SELECT classname_id FROM classname WHERE name = ?");
$stmt->execute([$classname]);
$classnameId = $stmt->fetchColumn();

$stmt = $pdo->prepare("SELECT classtype_id FROM classtype WHERE type = ?");
$stmt->execute([$classtype]);
$classtypeId = $stmt->fetchColumn();

if (!$classnameId || !$classtypeId) {
    die("Invalid class name or type.");
}

// Check for duplicate entry.
$stmt = $pdo->prepare("SELECT COUNT(*) FROM course_class WHERE classname_id = ? AND type_id = ? AND course_code = ?");
$stmt->execute([$classnameId, $classtypeId, $courseCode]);
if ($stmt->fetchColumn() > 0) {
    die("Duplicate entry exists.");
}

$stmt = $pdo->prepare("INSERT INTO course_class (classname_id, type_id, course_code) VALUES (?, ?, ?)");
if ($stmt->execute([$classnameId, $classtypeId, $courseCode])) {
    header("Location: modify.php?message=Class added successfully");
    exit;
} else {
    die("Failed to insert class.");
}
?>
