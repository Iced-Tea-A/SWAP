<?php
// delete.php
include 'db_connection.php';
session_start();

if (!isset($_SESSION['role_id']) || $_SESSION['role_id'] != 1) {
    header("Location: login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    die("Invalid request method.");
}

$id = $_POST['id'] ?? null;
if (!$id) {
    die("Invalid deletion request.");
}

$stmt = $pdo->prepare("DELETE FROM course_class WHERE course_class_id = ?");
if ($stmt->execute([$id])) {
    header("Location: modify.php?message=Deleted successfully");
    exit;
} else {
    die("Failed to delete.");
}
?>
