<?php
// edit.php
include 'db_connection.php';
session_start();

if (!isset($_SESSION['role_id']) || ($_SESSION['role_id'] != 1 && $_SESSION['role_id'] != 2)) {
    header("Location: login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    die("Invalid request method.");
}

if (!isset($_POST['id'], $_POST['newClassname'], $_POST['newClasstype'], $_POST['newCourseCode'])) {
    die("Missing parameters.");
}

$id = $_POST['id'];
$newClassname = trim($_POST['newClassname']);
$newClasstype = trim($_POST['newClasstype']);
$newCourseCode = trim($_POST['newCourseCode']);

// Retrieve the new class IDs.
$stmt = $pdo->prepare("SELECT classname_id FROM classname WHERE name = ?");
$stmt->execute([$newClassname]);
$classnameId = $stmt->fetchColumn();

$stmt = $pdo->prepare("SELECT classtype_id FROM classtype WHERE type = ?");
$stmt->execute([$newClasstype]);
$classtypeId = $stmt->fetchColumn();

if (!$classnameId || !$classtypeId) {
    die("Invalid class name or type.");
}

// Check for duplicate entry (excluding the current record).
$stmt = $pdo->prepare("SELECT COUNT(*) FROM course_class WHERE classname_id = ? AND type_id = ? AND course_code = ? AND course_class_id != ?");
$stmt->execute([$classnameId, $classtypeId, $newCourseCode, $id]);
if ($stmt->fetchColumn() > 0) {
    die("Duplicate entry exists.");
}

// Update the record.
$stmt = $pdo->prepare("UPDATE course_class SET classname_id = ?, type_id = ?, course_code = ? WHERE course_class_id = ?");
if ($stmt->execute([$classnameId, $classtypeId, $newCourseCode, $id])) {
    header("Location: modify.php?message=Class updated successfully");
    exit;
} else {
    die("Failed to update class.");
}
?>
