<?php
// edit_form.php
include 'db_connection.php';
session_start();

if (!isset($_SESSION['role_id']) || ($_SESSION['role_id'] != 1 && $_SESSION['role_id'] != 2)) {
    header("Location: login.php");
    exit;
}

$id = $_GET['id'] ?? null;
if (!$id) {
    die("Invalid request.");
}

// Fetch the record details using the unique id.
$stmt = $pdo->prepare("
    SELECT cc.course_class_id as id, c.name AS classname, t.type AS classtype, cc.course_code, co.name AS course_name 
    FROM course_class cc 
    JOIN classname c ON cc.classname_id = c.classname_id 
    JOIN classtype t ON cc.type_id = t.classtype_id 
    LEFT JOIN course co ON cc.course_code = co.course_code 
    WHERE cc.course_class_id = ?
");
$stmt->execute([$id]);
$record = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$record) {
    die("Record not found.");
}

// Retrieve options for the select elements.
$classnames = $pdo->query("SELECT name FROM classname")->fetchAll(PDO::FETCH_ASSOC);
$classtypes = $pdo->query("SELECT type FROM classtype")->fetchAll(PDO::FETCH_ASSOC);
$courses = $pdo->query("SELECT course_code FROM course")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Class</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
    <h2>Edit Class</h2>
    <form action="edit.php" method="POST">
        <input type="hidden" name="id" value="<?= htmlspecialchars($record['id']) ?>">
        
        <label for="classname">Class Name:</label>
        <select name="newClassname" id="classname" required>
            <?php foreach ($classnames as $option): ?>
                <option value="<?= htmlspecialchars($option['name']) ?>" <?= ($record['classname'] == $option['name'] ? 'selected' : '') ?>>
                    <?= htmlspecialchars($option['name']) ?>
                </option>
            <?php endforeach; ?>
        </select>
        <br>
        
        <label for="classtype">Class Type:</label>
        <select name="newClasstype" id="classtype" required>
            <?php foreach ($classtypes as $option): ?>
                <option value="<?= htmlspecialchars($option['type']) ?>" <?= ($record['classtype'] == $option['type'] ? 'selected' : '') ?>>
                    <?= htmlspecialchars($option['type']) ?>
                </option>
            <?php endforeach; ?>
        </select>
        <br>
        
        <label for="course_code">Course Code:</label>
        <select name="newCourseCode" id="course_code" required>
            <?php foreach ($courses as $option): ?>
                <option value="<?= htmlspecialchars($option['course_code']) ?>" <?= ($record['course_code'] == $option['course_code'] ? 'selected' : '') ?>>
                    <?= htmlspecialchars($option['course_code']) ?>
                </option>
            <?php endforeach; ?>
        </select>
        <br>
        
        <button type="submit">Update</button>
    </form>
    <button type="button" onclick="window.location.href='modify.php'">
  Cancel
</button>
    </div>
</body>
</html>
