<?php
include 'db_connection.php';
session_start();

require_once 'auth.php'; // Protect the page

if (!isset($_SESSION['role_id']) || ($_SESSION['role_id'] != 1 && $_SESSION['role_id'] != 2)) {
    header("Location: login.php");
    exit;
}

function toggleOrder($order) {
    return $order === 'ASC' ? 'DESC' : 'ASC';
}

// Pagination setup
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
if ($page < 1) $page = 1;
$itemsPerPage = 12;
$offset = ($page - 1) * $itemsPerPage;

// Fetch dropdown options (for the add form)
$classnames = $pdo->query("SELECT name FROM classname")->fetchAll(PDO::FETCH_ASSOC);
$classtypes = $pdo->query("SELECT type FROM classtype")->fetchAll(PDO::FETCH_ASSOC);
$courses    = $pdo->query("SELECT course_code FROM course")->fetchAll(PDO::FETCH_ASSOC);

// Sorting, searching, etc.
$sortColumn = $_GET['sort'] ?? 'classname';
$sortOrder = $_GET['order'] ?? 'ASC';
$searchQuery = trim($_GET['search'] ?? '');
$showEmptyClasses = isset($_GET['show_empty_classes']) && $_GET['show_empty_classes'] == "1";

// Count total records
$countQuery = "
    SELECT COUNT(*) as total
    FROM classname c
    LEFT JOIN course_class cc ON cc.classname_id = c.classname_id
    LEFT JOIN classtype t ON cc.type_id = t.classtype_id
    LEFT JOIN course co ON cc.course_code = co.course_code
    WHERE (c.name LIKE :search OR cc.course_code LIKE :search OR co.name LIKE :search)
";
if (!$showEmptyClasses) {
    $countQuery .= " AND cc.course_code IS NOT NULL";
}
$countStmt = $pdo->prepare($countQuery);
$countStmt->execute(['search' => "%$searchQuery%"]);
$totalRecords = $countStmt->fetchColumn();
$totalPages = ceil($totalRecords / $itemsPerPage);

// Fetch the actual records (including a unique id from course_class)
$query = "
    SELECT cc.course_class_id as id, c.name AS classname, t.type AS classtype, cc.course_code, co.name AS course_name
    FROM classname c
    LEFT JOIN course_class cc ON cc.classname_id = c.classname_id
    LEFT JOIN classtype t ON cc.type_id = t.classtype_id
    LEFT JOIN course co ON cc.course_code = co.course_code
    WHERE (c.name LIKE :search OR cc.course_code LIKE :search OR co.name LIKE :search)
";
if (!$showEmptyClasses) {
    $query .= " AND cc.course_code IS NOT NULL";
}
$query .= " ORDER BY $sortColumn $sortOrder LIMIT :limit OFFSET :offset";
$classesStmt = $pdo->prepare($query);
$classesStmt->bindValue(':search', "%$searchQuery%", PDO::PARAM_STR);
$classesStmt->bindValue(':limit', $itemsPerPage, PDO::PARAM_INT);
$classesStmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$classesStmt->execute();
$classes = $classesStmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Modify Classes</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <h2>Modify Classes</h2>
        <!-- Search Form -->
        <form method="GET" action="modify.php">
            <input type="text" name="search" placeholder="Search classes" value="<?= htmlspecialchars($searchQuery) ?>">
            <label>
                <input type="checkbox" name="show_empty_classes" value="1" <?= $showEmptyClasses ? 'checked' : '' ?>>
                Show Classes Without Course Code
            </label>
            <button type="submit">Search</button>
        </form>
        
        <!-- Existing Classes Table -->
        <h3>Existing Classes</h3>
        <table id="table">
            <thead>
                <tr>
                    <th><a href="?sort=classname&order=<?= toggleOrder($sortOrder) ?>&search=<?= urlencode($searchQuery) ?>&show_empty_classes=<?= $showEmptyClasses ? '1' : '0' ?>">Class Name</a></th>
                    <th><a href="?sort=classtype&order=<?= toggleOrder($sortOrder) ?>&search=<?= urlencode($searchQuery) ?>&show_empty_classes=<?= $showEmptyClasses ? '1' : '0' ?>">Class Type</a></th>
                    <th><a href="?sort=course_code&order=<?= toggleOrder($sortOrder) ?>&search=<?= urlencode($searchQuery) ?>&show_empty_classes=<?= $showEmptyClasses ? '1' : '0' ?>">Course Code</a></th>
                    <th><a href="?sort=course_name&order=<?= toggleOrder($sortOrder) ?>&search=<?= urlencode($searchQuery) ?>&show_empty_classes=<?= $showEmptyClasses ? '1' : '0' ?>">Course Name</a></th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($classes as $class): ?>
                <tr>
                    <td><?= htmlspecialchars($class['classname']) ?></td>
                    <td><?= htmlspecialchars($class['classtype']) ?></td>
                    <td><?= htmlspecialchars($class['course_code']) ?></td>
                    <td><?= htmlspecialchars($class['course_name']) ?></td>
                    <td>
                        <!-- Edit Link -->
                        <button type="button" onclick="window.location.href='edit_form.php?id=<?= urlencode($class['id']) ?>'">Edit
</button>
                        <!-- Delete Form (only for Admins) -->
                        <?php if ($_SESSION['role_id'] == 1): ?>
                        <form action="delete.php" method="POST" style="display:inline;" onsubmit="return;">
                            <input type="hidden" name="id" value="<?= htmlspecialchars($class['id']) ?>">
                            <button type="submit">Delete Entry</button>
                        </form>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        
        <!-- Pagination Links -->
        <div class="pagination">
            <?php if ($page > 1): ?>
                <a href="?page=<?= $page - 1 ?>&sort=<?= urlencode($sortColumn) ?>&order=<?= urlencode($sortOrder) ?>&search=<?= urlencode($searchQuery) ?>&show_empty_classes=<?= $showEmptyClasses ? '1' : '0' ?>">Previous</a>
            <?php endif; ?>
            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                <?php if ($i == $page): ?>
                    <span><?= $i ?></span>
                <?php else: ?>
                    <a href="?page=<?= $i ?>&sort=<?= urlencode($sortColumn) ?>&order=<?= urlencode($sortOrder) ?>&search=<?= urlencode($searchQuery) ?>&show_empty_classes=<?= $showEmptyClasses ? '1' : '0' ?>"><?= $i ?></a>
                <?php endif; ?>
            <?php endfor; ?>
            <?php if ($page < $totalPages): ?>
                <a href="?page=<?= $page + 1 ?>&sort=<?= urlencode($sortColumn) ?>&order=<?= urlencode($sortOrder) ?>&search=<?= urlencode($searchQuery) ?>&show_empty_classes=<?= $showEmptyClasses ? '1' : '0' ?>">Next</a>
            <?php endif; ?>
        </div>
        <form action="add.php" method="POST">
            <label for="new_classname">New Class Name:</label>
            <input type="text" id="new_classname" name="classname" placeholder="Enter new class name" required>
            <button type="submit">Add New Class Name</button>
        </form>
        <!-- Add New Class Form -->
        <h3>Add New Class</h3>
        <form action="add.php" method="POST">
            <label for="classname">Class Name:</label>
            <select name="classname" id="classname" required>
                <option value="">Select Class Name</option>
                <?php foreach ($classnames as $option): ?>
                    <option value="<?= htmlspecialchars($option['name']) ?>"><?= htmlspecialchars($option['name']) ?></option>
                <?php endforeach; ?>
            </select>
            <br>
            
            <label for="classtype">Class Type:</label>
            <select name="classtype" id="classtype" required>
                <option value="">Select Class Type</option>
                <?php foreach ($classtypes as $option): ?>
                    <option value="<?= htmlspecialchars($option['type']) ?>"><?= htmlspecialchars($option['type']) ?></option>
                <?php endforeach; ?>
            </select>
            <br>
            
            <label for="course_code">Course Code:</label>
            <select name="courseCode" id="course_code" required>
                <option value="">Select Course Code</option>
                <?php foreach ($courses as $option): ?>
                    <option value="<?= htmlspecialchars($option['course_code']) ?>"><?= htmlspecialchars($option['course_code']) ?></option>
                <?php endforeach; ?>
            </select>
            <br>
            
            <button type="submit">Add Class</button>
        </form>
    </div>
</body>
</html>
