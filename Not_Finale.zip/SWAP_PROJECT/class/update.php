<?php
include 'db_connection.php'; // Include the database connection file

session_start();

// Redirect if the user is not logged in or doesn't have role 4
if (!isset($_SESSION['role_id']) || ($_SESSION['role_id'] != 4 && $_SESSION['role_id'] != 3)) {
    header("Location: login.php"); // Redirect to login if not authenticated
    exit;
}

// Handle password update
$alertMessage = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($_SESSION['role_id'] == 4) {
        // If the user is role 4, they can only update password
        $newPassword = $_POST['new_password'] ?? '';
        $confirmPassword = $_POST['confirm_password'] ?? '';

        // Validate passwords
        if ($newPassword !== $confirmPassword) {
            $alertMessage = 'Passwords do not match!';
        } elseif (empty($newPassword) || empty($confirmPassword)) {
            $alertMessage = 'Please fill in both password fields.';
        } else {
            // Hash the new password and update it
            $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("UPDATE account SET password = ?, role_id = 3 WHERE email = ?");
            $stmt->execute([$hashedPassword, $_SESSION['email']]);

            // Update session role
            $_SESSION['role_id'] = 3;  // Change role_id to 3 after successful password reset

            $alertMessage = 'Your password has been updated successfully.';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Password</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="update-container">
        <h1>Update Password</h1>
        
        <?php if ($alertMessage): ?>
            <div class="alert"><?= htmlspecialchars($alertMessage) ?></div>
        <?php endif; ?>

        <form method="POST">
            <label for="new_password">New Password:</label>
            <input type="password" name="new_password" required>
            
            <label for="confirm_password">Confirm New Password:</label>
            <input type="password" name="confirm_password" required>
            
            <button type="submit">Update</button>
        </form>

        <?php if ($_SESSION['role_id'] == 3): ?>
            <!-- Navigation bar for role 3, to be added later -->
            <div class="navigation">
                <!-- You can insert your navigation bar code here -->
                <a href="dashboard.php">Dashboard</a>
                <a href="logout.php">Logout</a>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
