<?php
session_start();
$user_email = "zahid@gmail.com";
$user_role = "admin";
$_SESSION['user_role'] = $user_role;
$_SESSION['user_email'] = $user_email;

if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin' && $_SESSION['user_role'] !== 'faculty' && $_SESSION['user_role'] !== 'student') {
    session_unset(); //Remove session variables, destroy the session and bring user back to login page if unauthorised
    session_destroy();
    header("Location: login.php");
    exit();
    die("Access denied."); //Session start and ensure that current user role is either Faculty or Admin
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Education Portal</title>
    <link rel="stylesheet" href="style/style.css">
</head>
<body>
<header>
    <h1>Education Portal</h1>
</header>

<!-- Navigation Bar -->
<nav>
    <div class="dropdown">
    <button>Home</button>
        <div class="dropdown-content">
            <a href="home.php">Home page</a>
        </div>
    </div>
    <div class="dropdown">
        <button>Students</button>
        <div class="dropdown-content">
            <a href="students/index.php?route=students">Student Records</a>
            <a href="students/index.php?route=enrollment">Student Enrollment</a>
            <?php if ($_SESSION['user_role'] !== 'student'): ?>
                <a href="student_create.php">Add Student</a>
            <?php endif; ?>
        </div>
    </div>
    <?php if ($_SESSION['user_role'] !== 'student'): ?>
    <div class="dropdown">
        <button>Classes</button>
        <div class="dropdown-content">
        <a href="class/view.php">View Class</a>
        <a href="class/modify.php">Modify Class</a>
            <?php endif; ?>
        </div>
    </div>
    <?php if ($_SESSION['user_role'] !== 'student'): ?>
    <div class="dropdown">
        <button>Courses</button>
        <div class="dropdown-content">
            <a href="courses/read_courses.php">Course Main</a>
            <a href="courses/create_courses.php">Course Create</a>
            <?php endif; ?>
        </div>
    </div>
</nav>

<!-- Main Content --> 
<div class="container">
    <p>Welcome to the Education Portal. Use the navigation above to access different sections.</p>