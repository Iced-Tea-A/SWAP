<?php
session_start();
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
// Check user role for access control
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin' && $_SESSION['user_role'] !== 'faculty' && $_SESSION['user_role'] !== 'student') {
    session_unset(); //Remove session variables, destroy the session and bring user back to login page if unauthorised
    session_destroy();
    header("Location: ../login.php");
    exit();
    die("Access denied.");
}
//Database Connection
include('../sql/db.php');

$conn = getDbConnection();
// Define available routes and their corresponding files
$routes = [
    'students' => 'displaystudents.php',
    'edit' => 'editstudent.php',
    'assign' => 'assignstudent.php',
    'delete' => 'deletestudent.php',
    'add' => 'addstudent.php',
    'enrollment' => 'displaystudentcourse.php',
    'css' => '../style/style.css',
    'home' => '../home.php', // Default page
];

// Get the requested route from the URL
$route = $_GET['route'] ?? 'home'; // Default to 'home' if no route is provided
if (array_key_exists($route, $routes)) {
    $filePath = __DIR__ . '/' . $routes[$route]; // Use absolute paths to avoid directory traversal
    if (file_exists($filePath)) {
        include($filePath);
    } else {
        die("Error: File not found.");
    }
} else {
    session_unset(); //Remove session variables, destroy the session and bring user back to login page if unauthorised
    session_destroy();
    echo "Error: Invalid Route Specified. Please log in again.";
    echo "<a href='../login.php'>Click here to log in</a>";
    exit();  
    die("Invalid route specified.");
}

// Check if the route is valid, then include the corresponding file
// if (array_key_exists($route, $routes)) {
//     include($routes[$route]);
// } else {
//     die("Invalid route specified.");
// }
?>