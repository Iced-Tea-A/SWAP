<?php
$host = 'localhost';
$dbname = 'school';
$user = 'root';
$pass = '';

function getDbConnections() {
    global $host, $dbname, $user, $pass; // Access global variables
    $conn = new mysqli($host, $user, $pass, $dbname);

    // Check for connection errors
    if ($conn->connect_error) {
        die("Connection failed: " . htmlspecialchars($conn->connect_error));
    }

    return $conn; // Return the connection object
}
?>
