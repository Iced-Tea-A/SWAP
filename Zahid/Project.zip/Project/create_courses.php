<?php
session_start();

// Ensure session security by regenerating session ID
if (!isset($_SESSION['role'])) {
    die("Access Denied: Please log in first.");
}

// Role-based access control
if (!in_array($_SESSION['role'], ['Admin', 'Faculty'])) {
    die("Access Denied: You do not have permission to create a course.");
}

// Database connection
$conn = new mysqli('localhost', 'root', '', 'school');

if ($conn->connect_error) {
    error_log("Database connection failed: " . $conn->connect_error); // Log the error
    die("Connection failed. Please try again later.");
}

// CSRF Token Generation (if not already set)
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Fetch existing dates for the dropdown using JOIN
$date_options = [];
$date_query = "SELECT date.date_id, date.start, date.end FROM date";
$date_result = $conn->query($date_query);

if ($date_result->num_rows > 0) {
    while ($row = $date_result->fetch_assoc()) {
        $date_options[] = $row; // Store all rows for use in the dropdown
    }
}

// Fetch course statuses for the dropdown
$status_options = [];
$status_query = "SELECT status_id, name FROM status";
$status_result = $conn->query($status_query);

if ($status_result->num_rows > 0) {
    while ($row = $status_result->fetch_assoc()) {
        $status_options[] = $row; // Store all rows for use in the dropdown
    }
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Verify CSRF token
    if (empty($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        die("CSRF token validation failed.");
    }

    $course_code = $_POST['course_code'] ?? '';
    $name = $_POST['name'] ?? '';
    $date_id = $_POST['date_id'] ?? 0;
    $status_id = $_POST['status_id'] ?? 1; // Default to status "Start" if not selected

    // Validate input
    if (empty($course_code) || empty($name) || empty($date_id) || empty($status_id)) {
        echo "<script>alert('All fields are required.'); window.location.href='create_courses.php';</script>";
        exit;
    }

    // Validate course_code: Only letters (a-z, A-Z) and digits (1-9)
    if (!preg_match('/^[A-Za-z1-9]+$/', $course_code)) {
        echo "<script>alert('Course code must contain only letters (A-Z, a-z) and numbers (1-9).'); window.location.href='create_courses.php';</script>";
        exit;
    }

    // Use prepared statements to prevent SQL injection
    $stmt = $conn->prepare("INSERT INTO course (course_code, name, date_id, status_id) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssii", $course_code, $name, $date_id, $status_id);

    if ($stmt->execute()) {
        echo "<script>alert('New course created successfully.'); window.location.href='create_courses.php';</script>";
    } else {
        error_log("SQL Error: " . $stmt->error); // Log the error
        echo "<script>alert('An error occurred. Please try again later.'); window.location.href='create_courses.php';</script>";
    }
    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Create Course</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <header>
        <h1>Education Portal</h1>
    </header>
    
    <nav>
        <div class="dropdown">
            <button>Students</button>
            <div class="dropdown-content">
                <a href="student_records.php">Student Records</a>
                <a href="student_create.php">Add Student</a>
            </div>
        </div>
        <div class="dropdown">
            <button>Classes</button>
            <div class="dropdown-content">
                <a href="class_main.php">Class Main</a>
                <a href="class_details.php">Class Details</a>
                <a href="class_create.php">Create Class</a>
            </div>
        </div>
        <div class="dropdown">
            <button>Courses</button>
            <div class="dropdown-content">
                <a href="read_courses.php">Course Main</a>
                <a href="create_courses.php">Create Course</a>
            </div>
        </div>
    </nav>

    <div class="container">
        <h2>Create New Course</h2>
        <div class="formbox">
            <form method="post">
                <label for="name">Course Name:</label>
                <input type="text" id="name" name="name" required>

                <label for="course_code">Course Code:</label>
                <input type="text" id="course_code" name="course_code" required>

                <label for="date_id">Select Date:</label>
                <select name="date_id" id="date_id" required>
                    <option value="">-- Select Date Range --</option>
                    <?php foreach ($date_options as $date): ?>
                        <option value="<?= htmlspecialchars($date['date_id'], ENT_QUOTES, 'UTF-8') ?>">
                            <?= htmlspecialchars($date['start'], ENT_QUOTES, 'UTF-8') ?> - <?= htmlspecialchars($date['end'], ENT_QUOTES, 'UTF-8') ?>
                        </option>
                    <?php endforeach; ?>
                </select>

                <label for="status_id">Select Status:</label>
                <select name="status_id" id="status_id" required>
                    <option value="">-- Select Status --</option>
                    <?php foreach ($status_options as $status): ?>
                        <option value="<?= htmlspecialchars($status['status_id'], ENT_QUOTES, 'UTF-8') ?>">
                            <?= htmlspecialchars($status['name'], ENT_QUOTES, 'UTF-8') ?>
                        </option>
                    <?php endforeach; ?>
                </select>

                <!-- CSRF Token -->
                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">

                <button type="submit">Create Course</button>
            </form>
        </div>
    </div>
</body>
</html>
