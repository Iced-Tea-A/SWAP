<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Education Portal</title>
    <link rel="stylesheet" href="index.php">
</head>
<body>
<header>
    <h1>Education Portal</h1>
</header>
<nav>
    <div class="dropdown">
        <button>Students</button>
        <div class="dropdown-content">
            <a href="student_records.php">Student Records</a>
            <a href="student_create.php">Add Student</a>
        </div>
    </div>
    <div class="dropdown">
        <button>Classes</button>
        <div class="dropdown-content">
            <a href="class_main.php">Class Main</a>
            <a href="class_details.php">Class Details</a>
            <a href="class_create.php">Create Class</a>
        </div>
    </div>
    <div class="dropdown">
        <button>Courses</button>
        <div class="dropdown-content">
            <a href="read_courses.php">Course Main</a>
            <a href="create_courses.php">Create Course</a>
        </div>
    </div>
</nav>
