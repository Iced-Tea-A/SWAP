<?php
session_start();

// // Assuming role is set for demonstration purposes
// $_SESSION['role'] = 'Admin'; // This is just for demo, in real use, set this properly after login

// Database connection
$conn = new mysqli('localhost', 'root', '', 'school');
if ($conn->connect_error) {
    die("Connection failed: " . htmlspecialchars($conn->connect_error));
}

// Role-based access control
if (!isset($_SESSION['role']) || !in_array($_SESSION['role'], ['Admin', 'Faculty', 'Student'])) {
    die("Access Denied: You do not have permission to view courses.");
}

// CSRF Protection
if ($_SERVER['REQUEST_METHOD'] === 'POST' && (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token'])) {
    die("Invalid CSRF token.");
}

// Generate CSRF Token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Handle course deletion securely
if (isset($_GET['delete_course_code']) && $_SESSION['role'] === 'Admin') {
    $course_code_to_delete = $_GET['delete_course_code'];
    
    // Prepared statement for deletion
    $delete_query = "DELETE FROM course WHERE course_code = ?";
    if ($stmt = $conn->prepare($delete_query)) {
        $stmt->bind_param('s', $course_code_to_delete); // 's' for string
        if ($stmt->execute()) {
            // Redirect back to the same page after deletion
            header('Location: ' . htmlspecialchars($_SERVER['PHP_SELF']));
            exit();
        } else {
            error_log("Error deleting course: " . $stmt->error);
            echo "Error deleting course.";
        }
        $stmt->close();
    }
}

// Fetch courses securely
$course_query = "SELECT c.course_code, c.name as course_name, d.start, d.end, s.name as status_name
                 FROM course AS c
                 JOIN date AS d ON c.date_id = d.date_id
                 JOIN status AS s ON c.status_id = s.status_id";

if (!$course_result = $conn->query($course_query)) {
    error_log("Error fetching courses: " . $conn->error);
    die("Error fetching courses.");
}

// Ensure all output is sanitized
function escape($string) {
    return htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Education Portal</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<header>
    <h1>Education Portal</h1>
</header>

<!-- Navigation Bar -->
<nav>
    <div class="dropdown">
        <button>Students</button>
        <div class="dropdown-content">
            <a href="student_records.php">Student Records</a>
            <?php if ($_SESSION['role'] !== 'Student'): ?>
                <a href="student_create.php">Add Student</a>
            <?php endif; ?>
        </div>
    </div>
    <div class="dropdown">
        <button>Classes</button>
        <div class="dropdown-content">
            <a href="class_main.php">Class Main</a>
            <a href="class_details.php">Class Details</a>
            <?php if ($_SESSION['role'] !== 'Student'): ?>
                <a href="class_create.php">Create Class</a>
            <?php endif; ?>
        </div>
    </div>
    <div class="dropdown">
        <button>Courses</button>
        <div class="dropdown-content">
            <a href="read_courses.php">Course Main</a>
            <?php if ($_SESSION['role'] !== 'Student'): ?>
                <a href="create_courses.php">Create Course</a>
            <?php endif; ?>
        </div>
    </div>
</nav>

<!-- Main Content -->
<div class="container">
    <p>Welcome to the Education Portal. Use the navigation above to access different sections.</p>

    <h2>View Courses</h2>
    <table border="1" id="table">
        <thead>
            <tr>
                <th>Course Code</th>
                <th>Course Name</th>
                <th>Start Date</th>
                <th>End Date</th>
                <th>Status</th>
                <?php if ($_SESSION['role'] === 'Admin' || $_SESSION['role'] === 'Faculty'): ?>
                    <th>Actions</th>
                <?php endif; ?>
            </tr>
        </thead>
        <tbody>
            <?php if ($course_result->num_rows > 0): ?>
                <?php while ($row = $course_result->fetch_assoc()): ?>
                    <tr>
                        <td><?= escape($row['course_code']) ?></td>
                        <td><?= escape($row['course_name']) ?></td>
                        <td><?= escape($row['start']) ?></td>
                        <td><?= escape($row['end']) ?></td>
                        <td><?= escape($row['status_name']) ?></td>
                        <?php if ($_SESSION['role'] === 'Admin'): ?>
                            <td>
                                <a href="update_courses.php?course_code=<?= escape($row['course_code']) ?>">Edit</a> |
                                <a href="?delete_course_code=<?= escape($row['course_code']) ?>" onclick="return confirm('Are you sure you want to delete this course?')">Delete</a>
                            </td>
                        <?php elseif ($_SESSION['role'] === 'Faculty'): ?>
                            <td>
                                <a href="update_courses.php?course_code=<?= escape($row['course_code']) ?>">Edit</a>
                            </td>
                        <?php endif; ?>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="6">No courses found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <!-- Button to create a new course, visible to Admin and Faculty only -->
    <?php if ($_SESSION['role'] === 'Admin' || $_SESSION['role'] === 'Faculty'): ?>
        <form action="create_courses.php" method="get">
            <button type="submit" class="button">Add New Course</button>
        </form>
    <?php endif; ?>
</div>

</body>
</html>
