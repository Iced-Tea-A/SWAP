<?php
session_start();

// CSRF Token Generation and Validation
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32)); // Generate CSRF token if not set
}

// Database connection
$conn = new mysqli('localhost', 'root', '', 'school');

if ($conn->connect_error) {
    // Log the error securely
    error_log("Connection failed: " . $conn->connect_error);
    die("Connection failed. Please try again later.");
}

// Role-based access control
if (!isset($_SESSION['role']) || !in_array($_SESSION['role'], ['Admin', 'Faculty'])) {
    die("Access Denied: You do not have permission to edit courses.");
}

// Fetch available course statuses
$status_options = [];
$status_query = "SELECT status_id, name FROM status";
$status_result = $conn->query($status_query);
if ($status_result->num_rows > 0) {
    while ($row = $status_result->fetch_assoc()) {
        $status_options[] = $row; // Store all rows for use in the dropdown
    }
}

// Fetch available date ranges
$date_options = [];
$date_query = "SELECT date_id, start, end FROM date";
$date_result = $conn->query($date_query);
if ($date_result->num_rows > 0) {
    while ($row = $date_result->fetch_assoc()) {
        $date_options[] = $row; // Store all rows for use in the dropdown
    }
}

// Handle the update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // CSRF token validation
    if ($_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        die("CSRF token validation failed.");
    }

    // Validate and sanitize input data
    $course_code = $conn->real_escape_string($_POST['course_code'] ?? '');
    $course_name = $conn->real_escape_string($_POST['course_name'] ?? '');
    $status_id = (int) ($_POST['status_id'] ?? 1); // Default to status "Start" if not selected
    $date_id = (int) ($_POST['date_id'] ?? 1); // Default to the first date range if not selected

    // Input validation
    if (empty($course_code) || empty($course_name) || empty($status_id) || empty($date_id)) {
        echo "All fields are required.";
        exit;
    }

    // Ensure status_id and date_id are valid (must exist in the database)
    $status_check = $conn->prepare("SELECT 1 FROM status WHERE status_id = ?");
    $status_check->bind_param("i", $status_id);
    $status_check->execute();
    if ($status_check->get_result()->num_rows === 0) {
        die("Invalid status selected.");
    }

    $date_check = $conn->prepare("SELECT 1 FROM date WHERE date_id = ?");
    $date_check->bind_param("i", $date_id);
    $date_check->execute();
    if ($date_check->get_result()->num_rows === 0) {
        die("Invalid date selected.");
    }

    // Update the `course` table
    $update_course_sql = "UPDATE course SET name = ?, status_id = ?, date_id = ? WHERE course_code = ?";
    if ($stmt = $conn->prepare($update_course_sql)) {
        $stmt->bind_param("siss", $course_name, $status_id, $date_id, $course_code);
        if ($stmt->execute()) {
            // Redirect to course details page after success
            header('Location: read_courses.php');
            exit();
        } else {
            // Log the error securely
            error_log("Error updating course: " . $conn->error);
            echo "Error updating course. Please try again later.";
        }
        $stmt->close();
    }
}

// Fetch course details for editing
$course_code = $_GET['course_code'] ?? '';
$sql = "SELECT c.course_code, c.name, c.status_id, c.date_id 
        FROM course c 
        WHERE c.course_code = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $course_code);
$stmt->execute();
$result = $stmt->get_result();
$course = $result->fetch_assoc();
$stmt->close();

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Course</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <header>
        <h1>Education Portal</h1>
    </header>
    
    <nav>
        <div class="dropdown">
            <button>Students</button>
            <div class="dropdown-content">
                <a href="student_records.php">Student Records</a>
                <a href="student_create.php">Add Student</a>
            </div>
        </div>
        <div class="dropdown">
            <button>Classes</button>
            <div class="dropdown-content">
                <a href="class_main.php">Class Main</a>
                <a href="class_details.php">Class Details</a>
                <a href="class_create.php">Create Class</a>
            </div>
        </div>
        <div class="dropdown">
            <button>Courses</button>
            <div class="dropdown-content">
                <a href="read_courses.php">Course Main</a>
                <a href="create_courses.php">Create Course</a>
            </div>
        </div>
    </nav>

    <div class="container">
        <h2>Edit Course</h2>
        <div class="formbox">
            <form method="post">
                <!-- CSRF Token Hidden Field -->
                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">

                <label for="course_name">Course Name:</label>
                <input type="text" name="course_name" id="course_name" value="<?php echo htmlspecialchars($course['name']); ?>" required>

                <label for="course_code">Course Code:</label><input type="text" name="course_code" id="course_code" value="<?php echo htmlspecialchars($course['course_code']); ?>" required>


                <label for="date_id">Select Date:</label>
                <select name="date_id" id="date_id" required>
                    <option value="">-- Select Date Range --</option>
                    <?php foreach ($date_options as $date): ?>
                        <option value="<?= $date['date_id'] ?>" <?php if ($date['date_id'] == $course['date_id']) echo 'selected'; ?>>
                            <?= $date['start'] ?> - <?= $date['end'] ?>
                        </option>
                    <?php endforeach; ?>
                </select>

                <label for="status_id">Select Status:</label>
                <select name="status_id" id="status_id" required>
                    <option value="">-- Select Status --</option>
                    <?php foreach ($status_options as $status): ?>
                        <option value="<?= $status['status_id'] ?>" <?php if ($status['status_id'] == $course['status_id']) echo 'selected'; ?>>
                            <?= $status['name'] ?>
                        </option>
                    <?php endforeach; ?>
                </select>

                <button type="submit">Update Course</button>
            </form>
        </div>
    </div>
</body>
</html>
