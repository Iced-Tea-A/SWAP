<?php
// style.php
header("Content-type: text/css; charset: UTF-8");

// Serve the contents of your actual CSS file
echo file_get_contents('style.css');
?>